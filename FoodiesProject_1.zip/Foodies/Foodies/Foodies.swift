//
//  Foodies.swift
//  Foodies
//
//  Created by Joana Sosa on 10/28/24.
//

import Foundation
import UIKit

class Foodies{
    var foodName:String = ""
    var foodDescription:String = ""
    var foodAddress:String = ""
    var foodPriceRange = ""
    var foodType = ""
    var foodWebsite = ""
    var foodImage = ""
    var foodBackgroundColor: UIColor = UIColor(red: 153/255, green: 204/255, blue: 255/255, alpha:1.0)
}
