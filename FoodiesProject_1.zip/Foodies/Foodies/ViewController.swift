//
//  ViewController.swift
//  Foodies
//
//  Created by Joana Sosa on 10/22/24.
//

/* This App is developed as an educational project”. If any copyrighted materials are included in accordance to the
 multimedia fair use guidelines, a notice should be added and states that “certain materials are included under
 the fair use exemption of the U.S. Copyright Law and have been prepared according to the multimedia fair use
 guidelines and are restricted from further use”
 */

/* DISCLAMER: ALL images are not mine!
 The sound is from a CS101 Class from University of Illinois, Chicago
 www2.cs.uic.edu/~i101/SoundFiles/
 and from Professor Almedia from George Mason University
 
 Burger King image: www.google.com/url?sa=i&url=https%3A%2F%2F1000logos.net%2Fburger-king-logo%2F&psig=AOvVaw1U_N24SSeCtZRVQ9QUicL8&ust=1730249878958000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCNiugJ2xsokDFQAAAAAdAAAAABAJ
 Chick-fil-a image:
 www.google.com/url?sa=i&url=https%3A%2F%2Fwallpapers.com%2Fbackground%2Fchick-fil-a-background-cncyhztjsfr0xohc.html&psig=AOvVaw21Wok_qvXmIpDFNrifEZYT&ust=1730249323429000&source=images&cd=vfe&opi=89978449&ved=0CBcQjhxqFwoTCJCotJWvsokDFQAAAAAdAAAAABAE
 Cane's image: www.google.com/url?sa=i&url=https%3A%2F%2Fwww.youtube.com%2Fchannel%2FUCu4MUf6LJA5wl2uUeIxIMbw&psig=AOvVaw08Ox-Tt4XaXcJhARTrgn8b&ust=1730249765582000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCJi0uOewsokDFQAAAAAdAAAAABAE
 Chipotle's image:
www.google.com/url?sa=i&url=https%3A%2F%2Flogotyp.us%2Flogo%2Fchipotle%2F&psig=AOvVaw18SWf_o07Q_h6fP1bd3CCH&ust=1730249466694000&source=images&cd=vfe&opi=89978449&ved=0CBcQjhxqFwoTCNj9l9ivsokDFQAAAAAdAAAAABAI
 McDonald's image: www.google.com/url?sa=i&url=https%3A%2F%2Fwww.designrush.com%2Fbest-designs%2Flogo%2Fmcdonalds-logo&psig=AOvVaw3lHhRVrTXtkiH-Kig2ziAE&ust=1730249568523000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCJjJzoqwsokDFQAAAAAdAAAAABAE
 Panda Express image: www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pandaexpress.com%2F&psig=AOvVaw1mxarWVLbl3VDl7Eqz3JmX&ust=1730249709535000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCPDCw8ywsokDFQAAAAAdAAAAABAK
 Taco Bell image: www.google.com/url?sa=i&url=https%3A%2F%2Fwww.creativebloq.com%2Fnews%2Ftaco-bell-reveals-new-logo&psig=AOvVaw2fp5kbNDxX0x3ioIYibTSg&ust=1730249906033000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCMCD56qxsokDFQAAAAAdAAAAABAr
 Wingstop image: www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FWingstop&psig=AOvVaw3J4mh7groymyOT5Zi0fAsn&ust=1730249503128000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCICnwumvsokDFQAAAAAdAAAAABAc
 Wendy's image: www.google.com/url?sa=i&url=https%3A%2F%2Fworkingnotworking.com%2Fprojects%2F87159-wendy-s-red-campaign&psig=AOvVaw15YJLZOCfkCdk5LtHufFxp&ust=1730249837958000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCLD81YyxsokDFQAAAAAdAAAAABAE
*/

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var lblFoodImage: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblPriceRange: UILabel!
    @IBOutlet weak var lblType: UILabel!
    
    @IBOutlet weak var scAreaone: UIScrollView!
    
    var foodObjectArray = [Foodies]()
    var randomFood = Foodies()
    var mySoundFile: AVAudioPlayer!
    
    @IBAction func btnRandom(_ sender: Any) {
        setLabels()
    }
    
    @IBAction func btnWebsite(_ sender: Any) {
        let browserApp = UIApplication.shared
        let url = URL(string: randomFood.foodWebsite)
        browserApp.open(url!)
    }
    
    func setLabels(){
        randomFood = foodObjectArray.randomElement()!
        lblName.text = randomFood.foodName
        txtDescription.text = randomFood.foodDescription
        lblAddress.text = randomFood.foodAddress
        lblPriceRange.text = randomFood.foodPriceRange
        lblType.text = randomFood.foodType
        lblFoodImage.image = UIImage(named: randomFood.foodImage)
        
        txtDescription.layer.cornerRadius = 15
        txtDescription.layer.borderWidth = 1
        txtDescription.layer.borderColor = UIColor.white.cgColor
        
        lblFoodImage.layer.cornerRadius = 15
        lblFoodImage.layer.borderWidth = 1
        lblFoodImage.layer.borderColor = UIColor.white.cgColor
        
        scAreaone.layer.cornerRadius = 15
        scAreaone.layer.borderWidth = 1
        scAreaone.layer.borderColor = UIColor.white.cgColor
        
        self.view.backgroundColor = randomFood.foodBackgroundColor
        
        mySoundFile.play()
    }
    
    func populateFoodObjects(){
        let ht1 = Foodies()
        ht1.foodName = "Chick-fil-a"
        ht1.foodDescription = "Atlanta-based Chick-fil-A, Inc. is a family owned and privately held restaurant company founded in 1964 by S. Truett Cathy. Devoted to serving the local communities in which its franchised restaurants operate, and known for its original chicken sandwich, Chick-fil-A serves freshly prepared food."
        ht1.foodAddress = "9509 Fairfax Blvd"
        ht1.foodPriceRange = "$10-15"
        ht1.foodType = "Burgers"
        ht1.foodWebsite = "https://www.chick-fil-a.com/"
        ht1.foodImage = "Chick-fil-a.jpeg"
        ht1.foodBackgroundColor = UIColor(red:177/255, green:53/255, blue:59/255, alpha: 1.0)
        foodObjectArray.append(ht1)
        
        let ht2 = Foodies()
        ht2.foodName = "Wendy's"
        ht2.foodDescription = "At Wendy's, we're all about serving up fresh food, even if it means going the extra mile. When you walk through our doors, we do what we can to make everyone feel at home because our family extends through your community."
        ht2.foodAddress = "10695a Braddock Rd"
        ht2.foodPriceRange = "$5-15"
        ht2.foodType = "Burgers"
        ht2.foodWebsite = "https://www.wendys.com/"
        ht2.foodImage = "Wendy's.jpeg"
        ht2.foodBackgroundColor = UIColor(red:75/255, green:168/255, blue:255/255, alpha: 1.0)
        foodObjectArray.append(ht2)
        
        let ht3 = Foodies()
        ht3.foodName = "McDonald's"
        ht3.foodDescription = "McDonald's is one of the world's largest and most recognized fast-food chains, known for its hamburgers, french fries, and name-brand sandwiches such as the Big Mac, Quarter Pounder, and Egg McMuffin, as well as the child-focused Happy Meal."
        ht3.foodAddress = "10645 Braddock Rd"
        ht3.foodPriceRange = "$5-15"
        ht3.foodType = "Burgers"
        ht3.foodWebsite = "https://www.mcdonalds.com/us/en-us.html"
        ht3.foodImage = "McDonald's.jpeg"
        ht3.foodBackgroundColor = UIColor(red:244/255, green:196/255, blue:67/255, alpha: 1.0)
        foodObjectArray.append(ht3)
        
        let ht4 = Foodies()
        ht4.foodName = "Chipotle"
        ht4.foodDescription = "Chipotle was born of the radical belief that there is a connection between how food is raised and prepared, and how it tastes. Real is better. Better for You, Better for People, Better for Our Planet. It may be the hard way to do things, but it’s the right way."
        ht4.foodAddress = "4477 Aquia Creek Ln"
        ht4.foodPriceRange = "$10-20"
        ht4.foodType = "Bowls/burrios"
        ht4.foodWebsite = "https://www.chipotle.com/"
        ht4.foodImage = "Chipotle.jpeg"
        ht4.foodBackgroundColor = UIColor(red:154/255, green:39/255, blue:30/255, alpha: 1.0)
        foodObjectArray.append(ht4)
        
        let ht5 = Foodies()
        ht5.foodName = "Burger King"
        ht5.foodDescription = "Founded in 1954, BURGER KING® is the second largest fast food hamburger chain in the world. The original HOME OF THE WHOPPER®, our commitment to premium ingredients, signature recipes, and family-friendly dining experiences is what has defined our brand for more than 50 successful years."
        ht5.foodAddress = "10885 Lee Hwy"
        ht5.foodPriceRange = "$5-15"
        ht5.foodType = "Burgers"
        ht5.foodWebsite = "https://www.bk.com/"
        ht5.foodImage = "BurgerKing.jpeg"
        ht5.foodBackgroundColor = UIColor(red: 153/255, green: 204/255, blue: 255/255, alpha:1)
        foodObjectArray.append(ht5)
        
        let ht6 = Foodies()
        ht6.foodName = "Panda Express"
        ht6.foodDescription = "Panda Restaurant Group, the world leader in Asian dining experiences and parent company of Panda Inn, Panda Express and Hibachi-San, is dedicated to becoming a world leader in people development. Whether through sharing good food with guests or providing opportunities for professional and personal growth with associates, all are embraced in a genuine family environment that is uniquely Panda."
        ht6.foodAddress = "4441 George Mason Blvd University Hall"
        ht6.foodPriceRange = "$10-15"
        ht6.foodType = "Asian Fusion"
        ht6.foodWebsite = "https://www.pandaexpress.com/"
        ht6.foodImage = "PandaExpress.jpeg"
        ht6.foodBackgroundColor = UIColor(red:192/255, green:59/255, blue:55/255, alpha: 1.0)
        foodObjectArray.append(ht6)
        
        let ht7 = Foodies()
        ht7.foodName = "Taco Bell"
        ht7.foodDescription = "Taco Bell is a subsidiary of Yum! Brands, Inc. The restaurants serve a variety of Mexican-inspired foods, including tacos, burritos, quesadillas, nachos, novelty, and speciality items, and a variety of 'value menu' items."
        ht7.foodAddress = "12811 Federal Systems Park Dr"
        ht7.foodPriceRange = "$5-15"
        ht7.foodType = "Mexican Inspired"
        ht7.foodWebsite = "https://www.tacobell.com/"
        ht7.foodImage = "TacoBell.jpeg"
        ht7.foodBackgroundColor = UIColor(red:218/255, green:58/255, blue:141/255, alpha: 1.0)
        foodObjectArray.append(ht7)
        
        let ht8 = Foodies()
        ht8.foodName = "Cane's"
        ht8.foodDescription = "Raising Cane's is a restaurant company that has ONE LOVE- quality chicken finger meals. Cane's is known for its great crew, cool culture, and active community involvement."
        ht8.foodAddress = "9501 Liberia Aved"
        ht8.foodPriceRange = "$10-15"
        ht8.foodType = "Chicken fingers"
        ht8.foodWebsite = "https://www.raisingcanes.com/"
        ht8.foodImage = "Cane's.jpeg"
        ht8.foodBackgroundColor = UIColor(red:228/255, green:170/255, blue:63/255, alpha:1)
        foodObjectArray.append(ht8)
        
        let ht9 = Foodies()
        ht9.foodName = "Wing Stop"
        ht9.foodDescription = "Wingstop is the destination when you crave fresh never faked wings, hand-cut seasoned fries and any of our famous sides. For people who demand flavor in everything they do, there's only Wingstop - because it's more than a meal, it's a flavor experience."
        ht9.foodAddress = "11199 Lee Hwy F"
        ht9.foodPriceRange = "$10-20"
        ht9.foodType = "Chicken wings"
        ht9.foodWebsite = "https://www.wingstop.com/"
        ht9.foodImage = "Wingstop.jpeg"
        ht9.foodBackgroundColor = UIColor(red:68/255, green:132/255, blue:77/255, alpha: 1.0)
        foodObjectArray.append(ht9)
    }

    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        lblFoodImage.alpha = 0;
        lblName.alpha = 0;
    }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3, animations: {
            self.lblFoodImage.alpha = 1;
            self.lblName.alpha = 1;
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateFoodObjects()
        let soundUrl = URL(fileURLWithPath: Bundle.main.path(forResource:"blocker_hit", ofType: "wav")!)
        mySoundFile = try?AVAudioPlayer(contentsOf: soundUrl)
        setLabels()
    }
}
